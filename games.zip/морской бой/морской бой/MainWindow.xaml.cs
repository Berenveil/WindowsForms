﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace МорскойБой
{
    public partial class MainWindow : Window
    {
        const int size = 10;
        Button[,] player1Buttons = new Button[size, size];
        Button[,] player2Buttons = new Button[size, size];

        int[,] player1Ships = new int[size, size];
        int[,] player2Ships = new int[size, size];

        bool player1Ready = false;
        bool player2Ready = false;

        bool player1Turn = true;
        bool gameStarted = false;

        public MainWindow()
        {
            InitializeComponent();
            InitializeGrids();
        }

        void InitializeGrids()
        {
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    Button btn1 = new Button();
                    btn1.Tag = Tuple.Create(i, j);
                    btn1.Click += Player1Grid_Click;
                    Player1Grid.Children.Add(btn1);
                    player1Buttons[i, j] = btn1;
                    player1Ships[i, j] = 0;

                    Button btn2 = new Button();
                    btn2.Tag = Tuple.Create(i, j);
                    btn2.Click += Player2Grid_Click;
                    Player2Grid.Children.Add(btn2);
                    player2Buttons[i, j] = btn2;
                    player2Ships[i, j] = 0;
                }
            }

            var rnd = new Random();
            PlaceShipsRandomly(player1Ships, rnd);
            PlaceShipsRandomly(player2Ships, rnd);
        }

        void PlaceShipsRandomly(int[,] field, Random rnd)
        {
            int[] ships = { 4, 3, 3, 2, 2, 1, 1, 1, 1 };
            foreach (var shipLength in ships)
            {
                bool placed = false;
                while (!placed)
                {
                    int x = rnd.Next(size);
                    int y = rnd.Next(size);
                    bool horizontal = rnd.Next(2) == 0;

                    if (CanPlaceShip(field, x, y, shipLength, horizontal))
                    {
                        PlaceShip(field, x, y, shipLength, horizontal);
                        placed = true;
                    }
                }
            }
        }

        bool CanPlaceShip(int[,] field, int x, int y, int length, bool horizontal)
        {
            if (horizontal)
            {
                if (y + length > size) return false;
                for (int i = 0; i < length; i++)
                    if (field[x, y + i] == 1) return false;
            }
            else
            {
                if (x + length > size) return false;
                for (int i = 0; i < length; i++)
                    if (field[x + i, y] == 1) return false;
            }
            return true;
        }

        void PlaceShip(int[,] field, int x, int y, int length, bool horizontal)
        {
            for (int i = 0; i < length; i++)
            {
                if (horizontal)
                    field[x, y + i] = 1;
                else
                    field[x + i, y] = 1;
            }
        }

        private void Player1ReadyBtn_Click(object sender, RoutedEventArgs e)
        {
            player1Ready = true;
            MessageBox.Show("Игрок 1 готов!");
            CheckStartGame();
        }

        private void Player2ReadyBtn_Click(object sender, RoutedEventArgs e)
        {
            player2Ready = true;
            MessageBox.Show("Игрок 2 готов!");
            CheckStartGame();
        }

        void CheckStartGame()
        {
            if (player1Ready && player2Ready)
            {
                gameStarted = true;
                player1Turn = true;
                MessageBox.Show("Игра началась! Ходит игрок 1");
            }
        }

        private void Player1Grid_Click(object sender, RoutedEventArgs e)
        {
            if (gameStarted && player1Turn)
            {
                Button btn = sender as Button;
                var pos = (Tuple<int, int>)btn.Tag;
                int x = pos.Item1;
                int y = pos.Item2;

                if (player2Ships[x, y] == 2 || player2Ships[x, y] == 3)
                    return;

                if (player2Ships[x, y] == 1)
                {
                    btn.Background = Brushes.Red;
                    player2Ships[x, y] = 2;
                    MessageBox.Show("Попадание!");
                    if (IsAllShipsSunk(player2Ships))
                    {
                        MessageBox.Show("Игрок 1 выиграл!");
                        gameStarted = false;
                        return;
                    }
                }
                else
                {
                    btn.Background = Brushes.LightBlue;
                    player2Ships[x, y] = 3;
                    MessageBox.Show("Мимо");
                    player1Turn = false;
                    MessageBox.Show("Ходит игрок 2");
                }
            }
        }

        private void Player2Grid_Click(object sender, RoutedEventArgs e)
        {
            if (gameStarted && !player1Turn)
            {
                Button btn = sender as Button;
                var pos = (Tuple<int, int>)btn.Tag;
                int x = pos.Item1;
                int y = pos.Item2;

                if (player1Ships[x, y] == 2 || player1Ships[x, y] == 3)
                    return;

                if (player1Ships[x, y] == 1)
                {
                    btn.Background = Brushes.Red;
                    player1Ships[x, y] = 2;
                    MessageBox.Show("Попадание!");
                    if (IsAllShipsSunk(player1Ships))
                    {
                        MessageBox.Show("Игрок 2 выиграл!");
                        gameStarted = false;
                        return;
                    }
                }
                else
                {
                    btn.Background = Brushes.LightBlue;
                    player1Ships[x, y] = 3;
                    MessageBox.Show("Мимо");
                    player1Turn = true;
                    MessageBox.Show("Ходит игрок 1");
                }
            }
        }

        bool IsAllShipsSunk(int[,] shipsField)
        {
            for (int i = 0; i < size; i++)
                for (int j = 0; j < size; j++)
                    if (shipsField[i, j] == 1)
                        return false;
            return true;
        }
    }
}