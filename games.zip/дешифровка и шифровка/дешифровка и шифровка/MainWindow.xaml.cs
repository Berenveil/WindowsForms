﻿using System.Text;
using System.Windows;
using System.Windows.Controls;

namespace WpfApp1
{
    public partial class MainWindow : Window
    {
        private string alphabet = "абвгдеёжзиклмнопрстуфхцчшъыьэюя";

        public MainWindow()
        {
            InitializeComponent();
        }

        private string CaesarEncrypt(string input, int shift)
        {
            StringBuilder result = new StringBuilder();

            foreach (char c in input)
            {
                int index = alphabet.IndexOf(c);
                if (index >= 0)
                {
                    int newIndex = (index + shift) % alphabet.Length;
                    result.Append(alphabet[newIndex]);
                }
                else
                {
                    result.Append(c);
                }
            }
            return result.ToString();
        }

        private string CaesarDecrypt(string input, int shift)
        {
            return CaesarEncrypt(input, alphabet.Length - shift);
        }

        private string AtbashTransform(string input)
        {
            string alphabet = "абвгдеёжзийклмнопрстуфхцчшъыьэюя";
            string alphabetAtbash = "яюэьыъшщчцхфутсрпонмлкизжёедгвба";
            StringBuilder sb = new StringBuilder();

            foreach (char c in input)
            {
                int idx = alphabet.IndexOf(c);
                if (idx >= 0)
                {
                    sb.Append(alphabetAtbash[idx]);
                }
                else
                {
                    sb.Append(c);
                }
            }
            return sb.ToString();
        }

        private string Base64Encrypt(string input)
        {
            byte[] bytes = Encoding.UTF8.GetBytes(input);
            return System.Convert.ToBase64String(bytes);
        }

        private string Base64Decrypt(string input)
        {
            try
            {
                byte[] bytes = System.Convert.FromBase64String(input);
                return Encoding.UTF8.GetString(bytes);
            }
            catch
            {
                return "Некорректный формат Base64";
            }
        }

        private void Yes_Click(object sender, RoutedEventArgs e)
        {
            ProcessCipher(true);
        }

        private void No_Click(object sender, RoutedEventArgs e)
        {
            ProcessCipher(false);
        }

        private void ProcessCipher(bool isEncryption)
        {
            string input = InputText.Text;
            string method = (Combo.SelectedItem as ComboBoxItem)?.Content.ToString();
            string result = "";
            int shift = 3;

            switch (method)
            {
                case "Шифр Цезаря":
                    result = isEncryption ? CaesarEncrypt(input, shift) : CaesarDecrypt(input, shift);
                    break;
                case "Атбаш":
                    result = AtbashTransform(input);
                    break;
                case "Base64":
                    result = isEncryption ? Base64Encrypt(input) : Base64Decrypt(input);
                    break;
                default:
                    result = "Выберите метод шифрования!";
                    break;
            }

            ResultText.Text = result;
        }
    }
}