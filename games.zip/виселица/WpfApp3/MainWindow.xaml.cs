﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace HangmanWPF
{
    public partial class MainWindow : Window
    {
        private readonly List<string> words = new() { "ПК", "РОБОТ", "ГНОМ", "ПУСТОТА" };
        private string selectedWord;
        private HashSet<char> guessedLetters = new();
        private int mistakes = 0;
        private const int maxMistakes = 6;

        public MainWindow()
        {
            InitializeComponent();
            StartGame();
        }

        private void StartGame()
        {
            var rand = new Random();
            selectedWord = words[rand.Next(words.Count)];
            guessedLetters.Clear();
            mistakes = 0;
            Result.Text = "";
            TextBlock.Text = string.Join(" ", selectedWord.Select(c => '_'));
            Text.Text = $"Осталось попыток: {maxMistakes}";
        }

        private void CheckLetterClick(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(LetterTextBox.Text))
                return;

            char letter = char.ToUpper(LetterTextBox.Text[0]);
            LetterTextBox.Clear();

            guessedLetters.Add(letter);

            if (selectedWord.Contains(letter))
            {
                var displayWord = selectedWord
                    .Select(c => guessedLetters.Contains(c) ? c : '_')
                    .ToArray();
                TextBlock.Text = string.Join(" ", displayWord);

                if (selectedWord.All(c => guessedLetters.Contains(c)))
                {
                    Result.Text = "Вы победили!";
                }
            }
            else
            {
                mistakes++;
                int remaining = maxMistakes - mistakes;
                Text.Text = $"Осталось попыток: {remaining}";
                if (mistakes >= maxMistakes)
                {
                    Result.Text = $"Проигрыш! Загаданное слово: {selectedWord}";
                }
            }
        }
    }
}