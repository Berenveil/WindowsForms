﻿using BookShop.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApp4;

namespace BookShop
{
    /// <summary>
    /// Логика взаимодействия для LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }
        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            string name = tbName.Text.Trim();
            if (string.IsNullOrEmpty(name))
            {
                MessageBox.Show("Введите имя");
                return;
            }

            var selectedRole = (cbRole.SelectedItem as ComboBoxItem)?.Content.ToString();

            UserRole role;
            switch (selectedRole)
            {
                case "Гость": role = UserRole.Guest; break;
                case "Менеджер": role = UserRole.Manager; break;
                case "Администратор": role = UserRole.Admin; break;
                default: role = UserRole.Guest; break;
            }

            var user = new User { Name = name, Role = role };
            var mainWin = new MainWindow(user);
            mainWin.Show();
            this.Close();
        }
    }
}
