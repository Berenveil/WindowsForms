﻿namespace BookShop.Models
{
    public class Book
    {
        public string ImagePath { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public string Genre { get; set; }
        public int Year { get; set; }
        public decimal Price { get; set; }
        public int Stock { get; set; }
    }
}