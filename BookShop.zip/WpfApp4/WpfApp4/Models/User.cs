﻿namespace BookShop.Models
{
    public enum UserRole { Guest, Manager, Admin }

    public class User
    {
        public string Name { get; set; }
        public UserRole Role { get; set; }
    }
}