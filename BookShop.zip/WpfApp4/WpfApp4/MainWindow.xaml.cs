﻿using System.Collections.ObjectModel;
using System.Windows;
using BookShop.Models;

namespace BookShop
{
    public partial class MainWindow : Window
    {
        public ObservableCollection<Book> Books { get; set; } = new ObservableCollection<Book>();
        public User CurrentUser { get; set; }
        public bool IsEditVisible => CurrentUser?.Role == UserRole.Manager || CurrentUser?.Role == UserRole.Admin;
        public bool IsDeleteVisible => CurrentUser?.Role == UserRole.Admin;

        public MainWindow()
        {
            InitializeComponent();
        }

        public MainWindow(User user) : this()
        {
            CurrentUser = user;
            DataContext = this;
            LoadBooks();
            if (CurrentUser.Role == UserRole.Admin)
                btnAddBook.Visibility = Visibility.Visible;
            else
                btnAddBook.Visibility = Visibility.Collapsed;
        }

        private void LoadBooks()
        {
            for (int i = 1; i <= 50; i++)
            {
                Books.Add(new Book
                {
                    ImagePath = "images/book.png",
                    Title = $"Книга {i}",
                    Author = $"Автор {i}",
                    Genre = "Фантастика",
                    Year = 2000 + i % 20,
                    Price = 100 + i,
                    Stock = 5 + i % 12
                });
            }
        }

        private void btnAddBook_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Добавление книги (реализуйте отдельное окно добавления)");
        }

        private void EditBook_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as FrameworkElement;
            var book = button?.DataContext as Book;
            if (book == null) return;
            MessageBox.Show($"Редактировать: {book.Title} (реализуйте отдельное окно редактирования)");
        }

        private void DeleteBook_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as FrameworkElement;
            var book = button?.DataContext as Book;
            if (book == null) return;
            if (MessageBox.Show($"Удалить '{book.Title}'?", "Подтверждение", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                Books.Remove(book);
            }
        }
    }
}