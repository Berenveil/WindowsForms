﻿using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Threading;

namespace TaskManager
{
    public partial class MainWindow : Window
    {
        ObservableCollection<TaskItem> Tasks = new ObservableCollection<TaskItem>();
        DispatcherTimer timer = new DispatcherTimer();

        public MainWindow()
        {
            InitializeComponent();
            TaskListBox.ItemsSource = Tasks;

            timer.Interval = TimeSpan.FromSeconds(30);
            timer.Tick += (s, e) =>
            {
                foreach (var t in Tasks)
                {
                    if (!t.IsNotified && t.DueDate <= DateTime.Now)
                    {
                        MessageBox.Show($"Задача \"{t.Description}\" просрочена!");
                        t.IsNotified = true;
                    }
                }
            };
            timer.Start();
        }

        private void AddTaskButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TaskDescriptionTextBox.Text) || DueDatePicker.SelectedDate == null)
                return;

            Tasks.Add(new TaskItem
            {
                Description = TaskDescriptionTextBox.Text,
                DueDate = DueDatePicker.SelectedDate.Value,
                IsNotified = false
            });
            TaskDescriptionTextBox.Clear();
            DueDatePicker.SelectedDate = null;
        }

        private void DeleteTaskMenuItem_Click(object sender, RoutedEventArgs e)
        {
            if (TaskListBox.SelectedItem is TaskItem task)
                Tasks.Remove(task);
        }
    }

    public class TaskItem
    {
        public string Description { get; set; }
        public DateTime DueDate { get; set; }
        public bool IsNotified { get; set; }
        public string DisplayText => $"{Description} - {DueDate:g}";
    }
}